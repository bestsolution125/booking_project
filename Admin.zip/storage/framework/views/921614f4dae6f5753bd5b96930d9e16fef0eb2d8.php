
<?php $__env->startSection('title'); ?>
<?php echo app('translator')->get('translation.Calendar'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <link href="<?php echo e(URL::asset('assets/libs/fullcalendar/fullcalendar.min.css')); ?>" rel="stylesheet" type="text/css" />>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php $__env->startComponent('common-components.breadcrumb'); ?>
    <?php $__env->slot('pagetitle'); ?> Apps <?php $__env->endSlot(); ?>
    <?php $__env->slot('title'); ?> Calendar Import Update <?php $__env->endSlot(); ?>
<?php if (isset($__componentOriginalca1ecd71c079b0986f63b19e32f1541d590c0929)): ?>
<?php $component = $__componentOriginalca1ecd71c079b0986f63b19e32f1541d590c0929; ?>
<?php unset($__componentOriginalca1ecd71c079b0986f63b19e32f1541d590c0929); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
    <div class="row">
      <div class="col-lg-12">
      
        <div class="card">
          <div class="card-body">
            <h4 class="card-title">Calendar Import Update</h4>
            
            <form class="needs-validation" name="event-form" id="form-event" action="<?php echo e(route('calendars.update', $calendar->id)); ?>" method = "POST" novalidate>
            <?php echo method_field('PUT'); ?> 
            <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-12">
                        <div class="form-group">
                            <label class="control-label">Name</label>
                            <input class="form-control" placeholder="Insert Name"
                                type="text" name="name" id="event-title" required value="<?php echo e($calendar->name); ?>" />
                            <div class="invalid-feedback">Please provide a valid Name</div>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="form-group">
                            <label class="control-label">URL</label>
                            <input class="form-control" placeholder="Insert URL"
                                type="text" name="url" id="event-title" required value="<?php echo e($calendar->url); ?>" />
                            <div class="invalid-feedback">Please provide a valid URL</div>
                        </div>
                    </div>
                </div>
                <div class="row mt-2">
                    <div class="col-12 text-right">
                        <button type="button" class="btn btn-light mr-1" data-dismiss="modal"><a href="<?php echo e(route('calendars.index')); ?>">Back</a></button>
                        <button type="submit" class="btn btn-success" id="btn-save-event">Update</button>
                    </div>
                </div>
            </form>

          </div>
        </div>
      </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <!-- apexcharts -->
    <script src="<?php echo e(URL::asset('assets/libs/moment/moment.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/libs/jquery-ui-dist/jquery-ui-dist.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/libs/fullcalendar/fullcalendar.min.js')); ?>"></script>

    <!-- Calendar init -->
    <!-- <script src="<?php echo e(URL::asset('assets/js/pages/calendar.init.js')); ?>"></script> -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Minible_Laravel_v1.0.0\Admin\resources\views\calendar\edit.blade.php ENDPATH**/ ?>