
<?php $__env->startSection('title'); ?>
<?php echo app('translator')->get('translation.Starter_Page'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php $__env->startComponent('common-components.breadcrumb'); ?>
    <?php $__env->slot('pagetitle'); ?> Utility <?php $__env->endSlot(); ?>
    <?php $__env->slot('title'); ?> Starter Page <?php $__env->endSlot(); ?>
<?php if (isset($__componentOriginalca1ecd71c079b0986f63b19e32f1541d590c0929)): ?>
<?php $component = $__componentOriginalca1ecd71c079b0986f63b19e32f1541d590c0929; ?>
<?php unset($__componentOriginalca1ecd71c079b0986f63b19e32f1541d590c0929); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Minible_Laravel_v1.0.0\Admin\resources\views\pages-starter.blade.php ENDPATH**/ ?>