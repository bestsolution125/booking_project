<?php echo $__env->yieldContent('css'); ?>
<!-- Bootstrap Css -->
<link href="<?php echo e(URL::asset('assets/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" />
<!-- Icons Css -->
<link href="<?php echo e(URL::asset('assets/css/icons.min.css')); ?>" rel="stylesheet" type="text/css" />
<!-- App Css-->
<link href="<?php echo e(URL::asset('assets/css/app.min.css')); ?>" rel="stylesheet" type="text/css" /><?php /**PATH E:\xampp\htdocs\Minible_Laravel_v1.0.0\Admin\resources\views\layouts\head.blade.php ENDPATH**/ ?>